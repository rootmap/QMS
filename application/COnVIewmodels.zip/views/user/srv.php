<div class="left">
    <div id="accordian_id" class="accordion">                    
        <div class="accordion-group" id="survey">
            <div class="accordion-heading">
                <a href="#" data-parent="#" data-toggle="collapse" class="accordion-toggle">
                    Open Survey
                </a>
            </div>
            <div class="accordion-body in collapse" id="accordian_id6">
                <div class="accordion-inner">
                    <?php echo $open_survey_html; ?>
                </div>
            </div>
        </div>
    </div>                 
</div><!--left ends-->