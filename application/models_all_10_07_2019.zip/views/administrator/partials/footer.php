<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


    </div><!--maincontainer ends-->

<!--<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>-->

</body>
</html>