<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


<div class="row-fluid">
    <h1 class="heading">Dashboard</h1>
</div>

<div class="row-fluid">

        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?=$dashboard_data['total_exam']?></h3>

              <p>Total Exam</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/exam')?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?=$dashboard_data['total_exam_assignee']?></h3>

              <p>Total Assignee in Exam</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/assign_status')?>"  class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?=$dashboard_data['total_exam_attendee']?></h3>

              <p>Total Attendent Assignee</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/assign_status')?>"  class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?=$dashboard_data['total_exam_question_set']?></h3>

              <p>Total No Question Set</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/question')?>"  class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

</div>

<div class="row-fluid">

        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-fuchsia">
            <div class="inner">
              <h3><?=$dashboard_data['total_survey']?></h3>

              <p>Total Survey</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/survey')?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-lime">
            <div class="inner">
              <h3><?=$dashboard_data['total_assignee_in_survey']?></h3>

              <p>Total Assignee in Survey</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/assign_survey_status/survey_assign_list')?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-teal">
            <div class="inner">
              <h3><?=$dashboard_data['total_attendent_assignee_in_survey']?></h3>

              <p>Attendent Assignee in Survey</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/assign_survey_status/survey_assign_list')?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="span3">
          <!-- small box -->
          <div class="small-box bg-navy">
            <div class="inner">
              <h3><?=$dashboard_data['total_no_of_question_in_survey']?></h3>

              <p>Total No Question </p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a target="_blank" href="<?=base_url('administrator/survey_question')?>"  class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
</div>

<link rel="stylesheet" type="text/css" href="https://adminlte.io/themes/AdminLTE/dist/css/AdminLTE.min.css">