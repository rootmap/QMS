<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!--<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>-->


<div class="footer-wrap" style="text-align: center;"> 

    Copyright &copy; 2018. BRAC Bank Limited. 

 </div>


</div><!--#wrap ends-->


<script type="text/javascript">
	window.onload = function() {

    set_interval();

}

window.onmousemove = function() {

    reset_interval();

}

window.onclick = function() {

    reset_interval();

}
window.onmousemove = function() {

    reset_interval();

}
window.onkeypress = function() {

    reset_interval();

}
window.onscroll = function() {

    reset_interval();

}
	//onload="set_interval()"
//onmousemove="reset_interval()"
//onclick="reset_interval()"
//onkeypress="reset_interval()"
//onscroll="reset_interval()"
	</script>

</body>
</html>